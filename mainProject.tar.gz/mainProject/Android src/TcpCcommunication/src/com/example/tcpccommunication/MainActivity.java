package com.example.tcpccommunication;

import java.io.*;
import java.net.*;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TextView.BufferType;

public class MainActivity extends Activity {
	static Thread thread1; 
	public  static Socket clientSocket;
	static String msg;
	static String status=null;
	public final BufferType type = null;
	PrintWriter dataOut;  
	volatile boolean finished = false;  
		
		@Override
		public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);
			final TextView textView1=(TextView)findViewById(R.id.textView1);
			textView1.setText("Hello!",type);
			Button button1=(Button)findViewById(R.id.button1);
			Button button2=(Button)findViewById(R.id.button2);
			Button button3=(Button)findViewById(R.id.button3);
			Button button4=(Button)findViewById(R.id.button4);
			new Thread(new Runnable(){
       		 public void run(){
       			 	try{    
       			 			clientSocket = new Socket("192.168.1.143",5000);
	        			 	dataOut = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())), true);
	        			 	status="Connected Successfully";
		        		}
		        		catch(Exception e1){
			    			System.out.println(e1);
		        		}
       		 	}
       	 	}).start();
			if (status!=null)
				{textView1.setText(status,type);}
			else
				{textView1.setText("NO ROUTE TO HOST",type);}
			button1.setOnClickListener(new OnClickListener(){
		         public void onClick(View v) {
		        	 
		        	 try{    
			        		msg="Forward";
			 		 		System.out.println("Connected To: "+clientSocket);
	     			 		System.out.println("Message: "+msg);
	     			 		dataOut.println(msg);
				            dataOut.flush();
				            System.out.println("Sent!");           
	        		}
	        		catch(Exception e1){
		    			System.out.println(e1);
	        		}
		        		
		         	}
			}
			);
			button2.setOnClickListener(new OnClickListener(){
		         public void onClick(View v) {
		        	 
		        	 try{    
			        		msg="Reverse";
			        		System.out.println("Connected To: "+clientSocket);
	     			 		System.out.println("Message: "+msg);
	     			 		dataOut.println(msg);
				            dataOut.flush();
				            System.out.println("Sent!");           
	        		}
	        		catch(Exception e1){
		    			System.out.println(e1);
	        		}
		        		
		         	}
			}
			);
			button3.setOnClickListener(new OnClickListener(){
		         public void onClick(View v) {
		        	 
		        	 try{    
			        		msg="Left";
			 		 		System.out.println("Connected To: "+clientSocket);
	     			 		System.out.println("Message: "+msg);
	     			 		dataOut.println(msg);
				            dataOut.flush();
				            System.out.println("Sent!");           
	        		}
	        		catch(Exception e1){
		    			System.out.println(e1);
	        		}
		        		
		         	}
			}
			);
			button4.setOnClickListener(new OnClickListener(){
		         public void onClick(View v) {
		        	 
		        	 try{    
			        		msg="Right";
			 		 		System.out.println("Connected To: "+clientSocket);
	     			 		System.out.println("Message: "+msg);
	     			 		dataOut.println(msg);
				            dataOut.flush();
				            System.out.println("Sent!");           
	        		}
	        		catch(Exception e1){
		    			System.out.println(e1);
	        		}
		        		
		         	}
			}
			);
		}
	
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

}
