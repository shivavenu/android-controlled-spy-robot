package com.kevchris.videostream;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends Activity {
	public VideoView videoView;
	
	   @Override
	   protected void onCreate(Bundle savedInstanceState)
	   {
	     super.onCreate(savedInstanceState);
	
	     videoView = null;
	
	     setContentView(R.layout.activity_main);
	
	     videoView =(VideoView)findViewById(R.id.VideoView);
	     MediaController mediaController= new MediaController(this);
	     mediaController.setAnchorView(videoView);
	
	     // Uri uri =	 Uri.parse("rtsp://184.72.239.149/vod/mp4:BigBuckBunny_115k.mov");
	     Uri uri = Uri.parse("http://192.168.1.43:80/webcam.mjpeg");
	
	     videoView.setMediaController(mediaController);
	     videoView.setVideoURI(uri);
	     videoView.requestFocus();
	     videoView.start();
	  }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

}
