import java.net.*;
import java.io.*;
class centralserver implements Runnable
	{static Thread t[]=new Thread[1000];
	Socket s[]=new Socket[1000];
	static int i=1,n,k;
	static String msg;
	ServerSocket ss;
	centralserver()											//constructor
		{
		try	
			{ss=new ServerSocket(5000);
			while(true)
				{
				s[i]=ss.accept();
				System.out.println("connection with client "+i+" established");
				t[i]=new Thread(this);
				t[i].start();
				i++;
				}
			}
		catch(Exception e)
			{
			  System.out.println(e);
			}
		}
	
	public void run()
		{try	
			{do
				{int n;
				for(n=1;n<i;n++)
					{//System.out.println("hi\n");
					if (Thread.currentThread()==t[n])
						{String msg;
						BufferedReader din = new BufferedReader(new InputStreamReader(s[n].getInputStream()));       
						//DataInputStream din=new DataInputStream(s[n].getInputStream());
						do				
							{msg=din.readLine();
							System.out.println(msg+"\n");
							for(k=1;k<i;k++)
								{if(k!=n)
									{DataOutputStream dout=new DataOutputStream(s[k].getOutputStream());
									dout.writeBytes(n+": "+msg+"\n");
									}
								}
							}while(!(msg.equals("Quit")));	
						}
					}
				}while(!(msg.equals("Quit")));
			}
		 catch(Exception e)
			{
			System.out.println(e);
			}
		}

	public static void main(String args[])
		{
		centralserver cs1=new centralserver();
		}
	}
